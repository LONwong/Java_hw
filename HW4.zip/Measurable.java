package HW4;
public interface Measurable {
    double getMeasurement();  // 提供测量值的方法
}
